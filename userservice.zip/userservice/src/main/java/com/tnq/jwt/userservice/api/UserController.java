package com.tnq.jwt.userservice.api;

import static java.util.Arrays.stream;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.io.IOException;
import java.net.URI;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tnq.jwt.userservice.entity.AppUser;
import com.tnq.jwt.userservice.entity.Role;
import com.tnq.jwt.userservice.service.UserService;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/service")
@Slf4j
public class UserController {

	@Autowired
	private UserService service;
	
	@GetMapping("/users")
	public ResponseEntity<List<AppUser>> getUser(){
		return ResponseEntity.ok().body(service.getUsers());
	}
	
	@PostMapping("/user/save")
	public ResponseEntity<Object> saveUser(@RequestBody AppUser appUser){
		URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/user/save").toUriString());
		return ResponseEntity.created(uri).body(service.saveUser(appUser));
		
	}
	@PostMapping("/role/save")
	public ResponseEntity<Object> saveRole(@RequestBody Role role){
		URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/role/save").toUriString());
		return ResponseEntity.created(uri).body(service.saveRole(role));
		
	}
	
	@PostMapping("/role/addUser")
	public ResponseEntity<Object> addRole(@RequestBody RoleToUserForm roleUser){
		service.addRoletoUser(roleUser.getUsername(),roleUser.getName());
		return ResponseEntity.ok().build();
		
	}
	@GetMapping("/token/refresh")
	public void refreshToken(HttpServletRequest request,HttpServletResponse response) throws StreamWriteException, DatabindException, IOException{
		String authorizationHeader = request.getHeader(AUTHORIZATION);
		if(authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
			HashMap<String, String> error= new HashMap<String, String>();
			try {
				String refresh_token = authorizationHeader.substring("Bearer ".length());
				Algorithm algorithm = Algorithm.HMAC256("secret".getBytes());
				JWTVerifier jwtVerifier= JWT.require(algorithm).build();
				DecodedJWT decodedJWT = jwtVerifier.verify(refresh_token);
				String username = decodedJWT.getSubject();
				AppUser user = service.getUser(username);
				String accesToken=JWT.create().withSubject(user.getUsername()).withExpiresAt(new Date(System.currentTimeMillis()+10*60*1000))
				 .withIssuer(request.getRequestURI().toString())
				 .withClaim("roles",user.getRoles().stream().map(Role::getName).collect(Collectors.toList()))
				 .sign(algorithm);  
				Map<String, String> tokens = new HashMap<String, String>();
				tokens.put("accessToken",accesToken);
				response.setContentType(APPLICATION_JSON_VALUE);
				new ObjectMapper().writeValue(response.getOutputStream(), tokens);
			
			} catch (IllegalArgumentException | JWTVerificationException e) {
				// TODO Auto-generated catch block
				log.error("Error logging in : {} ", e.getMessage());
				response.setHeader("error", e.getMessage());
				response.setStatus(HttpStatus.FORBIDDEN.value());
//				response.sendError(HttpStatus.FORBIDDEN.value());		
				error.put("error", e.getMessage());
				response.setContentType(APPLICATION_JSON_VALUE);
				new ObjectMapper().writeValue(response.getOutputStream(), error);

			}
			catch (Exception e) {
				// TODO: handle excepion
				log.error("Error logging in : {} ", e.getMessage());
				response.setHeader("error", e.getMessage());
				response.setStatus(HttpStatus.FORBIDDEN.value());
//				response.sendError(HttpStatus.FORBIDDEN.value());		
				error.put("error", e.getMessage());
				response.setContentType(APPLICATION_JSON_VALUE);
				new ObjectMapper().writeValue(response.getOutputStream(), error);
									
			}
			
		}
		else {
			throw new RuntimeException("Refresh token missing");
		}
		
	}
}
@NoArgsConstructor
@AllArgsConstructor
@Data
class RoleToUserForm{
	private String username;
	private String name;
	
}
