package com.tnq.jwt.userservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tnq.jwt.userservice.entity.Role;

public interface RoleRepo extends JpaRepository<Role, Long> {

	Role findByName(String name);
	
}
