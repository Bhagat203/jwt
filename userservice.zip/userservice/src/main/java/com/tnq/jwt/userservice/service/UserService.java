package com.tnq.jwt.userservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tnq.jwt.userservice.entity.AppUser;
import com.tnq.jwt.userservice.entity.Role;

public interface UserService {

	AppUser saveUser(AppUser appUser);
	Role saveRole(Role role);
	void addRoletoUser(String username,String roleName);
	AppUser getUser(String username);
	List<AppUser> getUsers();
	 
}
