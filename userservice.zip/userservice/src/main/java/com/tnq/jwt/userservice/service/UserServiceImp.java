package com.tnq.jwt.userservice.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.tnq.jwt.userservice.entity.AppUser;
import com.tnq.jwt.userservice.entity.Role;
import com.tnq.jwt.userservice.repo.RoleRepo;
import com.tnq.jwt.userservice.repo.UserRepo;

import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;

@Transactional
@Slf4j
@Service
public class UserServiceImp implements UserService ,UserDetailsService {

	@Autowired
	private  UserRepo repoUser;
	@Autowired
	private  RoleRepo repoRole;
	@Autowired
	private PasswordEncoder encoder;
	@Override
	public AppUser saveUser(AppUser appUser) {
		// TODO Auto-generated method stub
		log.info("Saving user in service");
		appUser.setPassword(encoder.encode(appUser.getPassword()));
		return repoUser.save(appUser);
	}

	@Override
	public Role saveRole(Role role) {
		// TODO Auto-generated method stub
		log.info("Saving the role in service ");
		return repoRole.save(role);
	}

	@Override
	public void addRoletoUser(String username, String roleName) {
		// TODO Auto-generated method stub
		log.info("Adding role to user in service ");
		AppUser appUser = repoUser.findByUsername(username);
		Role role = repoRole.findByName(roleName);
		appUser.getRoles().add(role);
	}

	@Override
	public AppUser getUser(String username) {
		// TODO Auto-generated method stub
		log.info("Fetching the user in service ");
		return repoUser.findByUsername(username);
	}

	@Override
	public List<AppUser> getUsers() {
		// TODO Auto-generated method stub
		log.info("fetching the all user");
		return repoUser.findAll();
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		AppUser appUser = repoUser.findByUsername(username);
		if(appUser==null) {
			log.error("User Name not Found");
			throw new UsernameNotFoundException("user name is wrong : " +username);
		}
		else {
			log.info("user found");
		}
		Collection<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
		appUser.getRoles().forEach(role->{
			authorities.add(new SimpleGrantedAuthority(role.getName()));
		});
		return new User(username, appUser.getPassword(), authorities);
	}

}
